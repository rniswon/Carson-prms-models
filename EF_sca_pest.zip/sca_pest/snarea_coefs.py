import os

#read in parameters
infile='snarea_coefs_input.txt'
with open(infile,'r') as f:
    lines=f.readlines()
par={}
for l in lines:
    if l[0]!='#' and len(l)>1:
        data=l.strip().split('=')
        k=data[0]
        v=data[1]
        par[k]=v
#convert to params
parf=par['parf']

with open(parf,'r') as f:
    lines=f.readlines()
with open('snarea_coefs_output.txt','w+') as f:
    for i,line in enumerate(lines):
        if 'snarea_curve' in line:
            i=i+3
            ndeplval=int(lines[i])
            ndepl=int(ndeplval/11)
            i=i+2
            for h in range(0,ndepl):
                dh=h*11
                for k in range(0,10):
                    name='dsn'+str(k+1).zfill(2)+'_'+str(k).zfill(2)+'h'+str(h+1).zfill(3)
                    f.write(name+'    ')
                    f.write(str(float(lines[i+dh+k+1])-float(lines[i+dh+k]))+'\n')